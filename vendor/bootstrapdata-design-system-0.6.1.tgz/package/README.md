# @bootstrapdata/design-system

[![CI](https://github.com/bootstrapdata/data-platform-design-system/actions/workflows/ci.yml/badge.svg)](https://github.com/bootstrapdata/data-platform-design-system/actions/workflows/ci.yml)
[![Release](https://github.com/bootstrapdata/data-platform-design-system/actions/workflows/release.yml/badge.svg)](https://github.com/bootstrapdata/data-platform-design-system/actions/workflows/release.yml)

> The shared design system for the **Bootstrap Data** platform — shadcn/ui components, brand theme & assets, a framework-agnostic application layout, a TanStack-powered data table, and typography primitives.

Built with **React 19**, **Tailwind CSS v4**, **Radix UI**, and **TanStack Table**. Distributed as ESM with type declarations and consumable across multiple apps (including Module Federation hosts/remotes).

---

## Table of contents

- [Features](#features)
- [Requirements](#requirements)
- [Installation](#installation)
- [Quick start](#quick-start)
- [Exports](#exports)
- [Theming](#theming)
- [Components](#components)
- [Brand assets](#brand-assets)
- [Module Federation](#module-federation)
- [Development](#development)
- [Scripts](#scripts)
- [Project structure](#project-structure)
- [Adding a component](#adding-a-component)
- [Releasing](#releasing)
- [License](#license)

---

## Features

- 🎨 **Theme & tokens** — OKLCH design tokens (indigo/violet brand, hue 277), light & dark, exposed as Tailwind v4 `@theme` variables.
- 🧩 **shadcn/ui primitives** — the full component set, re-exported and tree-shakeable.
- 🏗️ **Application layout** — `AppShell`, `AppSidebar`, `SiteHeader`, `Breadcrumbs`, `PageHeader`, `SectionTabs` — fully decoupled from any router/store/i18n.
- 📊 **DataTable** — built on TanStack Table: sorting, faceted filters, column visibility, pagination, row selection, CSV export, and server-side mode.
- ✍️ **Typography** — a `Text` primitive (variants/tones/weights, truncation + tooltip) and `CopyableText`.
- 🔖 **Brand assets** — logo, mark, and generated favicons (SVG/PNG/ICO) + web manifest.
- ♿ **Accessible** — linted with `jsx-a11y` and verified in Storybook.

## Requirements

| Peer dependency         | Version     |
| ----------------------- | ----------- |
| `react`                 | `^19`       |
| `react-dom`             | `^19`       |
| `lucide-react`          | `>=0.475.0` |
| `tailwindcss`           | `^4`        |
| `@tanstack/react-table` | `^8.20.0`   |

- **Node** `>= 24.16.0`
- A Tailwind CSS v4 build in the consuming app.

### Bundled libraries

`@xyflow/react`, `@monaco-editor/react` + `monaco-editor`, `@dnd-kit/*` and `sql-formatter` all ship as **regular dependencies** — installing `@bootstrapdata/design-system` brings them along, so the `/flow`, `/code-editor` and `/dnd` subpaths work with **no additional install**.

## Installation

```bash
npm install @bootstrapdata/design-system
```

The package is published to a private registry. Add the scope resolution to the consuming app's `.npmrc`:

```ini
@bootstrapdata:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${GITHUB_TOKEN}
```

Install the peers if you don't already have them:

```bash
npm install react react-dom lucide-react @tanstack/react-table
```

## Quick start

**1. Import the theme** into your Tailwind v4 entry CSS (your app owns `@import "tailwindcss"`):

```css
@import "tailwindcss";
@import "tw-animate-css";
@import "@bootstrapdata/design-system/theme.css";

/* Let Tailwind scan the compiled components for class names */
@source "../../node_modules/@bootstrapdata/design-system/dist";
```

**2. Use the components:**

```tsx
import { Button, Text } from "@bootstrapdata/design-system";
import { AppShell, AppSidebar, SiteHeader, Breadcrumbs } from "@bootstrapdata/design-system/layout";

export function App() {
  return (
    <AppShell
      sidebar={<AppSidebar groups={nav} currentPath={pathname} linkComponent={NavLink} />}
      header={<SiteHeader breadcrumbs={<Breadcrumbs items={crumbs} linkComponent={Link} />} />}
    >
      <Text variant="title">Hello</Text>
    </AppShell>
  );
}
```

**3. Toggle dark mode** by adding the `dark` class to a parent element (e.g. `<html class="dark">`).

## Exports

| Entry point                                      | Contents                                                                                            |
| ------------------------------------------------ | --------------------------------------------------------------------------------------------------- |
| `@bootstrapdata/design-system`                   | Everything (primitives + layout + data-table + typography + brand)                                  |
| `@bootstrapdata/design-system/ui`                | shadcn/ui primitives only                                                                           |
| `@bootstrapdata/design-system/layout`            | `AppShell`, `AppSidebar`, `SiteHeader`, `Breadcrumbs`, `PageHeader`, `SectionTabs`, `SectionLayout` |
| `@bootstrapdata/design-system/data-table`        | `DataTable`, `useDataTable`, toolbar/header/filter/pagination parts, `exportTableToCsv`             |
| `@bootstrapdata/design-system/typography`        | `Text`, `CopyableText`, `textVariants`                                                              |
| `@bootstrapdata/design-system/wizard`            | `Wizard`, `WizardStepper`                                                                           |
| `@bootstrapdata/design-system/code-editor`       | `CodeEditor` (Monaco), `formatSql` + `sql-formatter` helpers                                        |
| `@bootstrapdata/design-system/flow`              | `Flow` + all `@xyflow/react` primitives                                                             |
| `@bootstrapdata/design-system/dnd`               | `SortableList` + all `@dnd-kit` primitives                                                          |
| `@bootstrapdata/design-system/query-builder`     | `QueryBuilder` + all `react-querybuilder` primitives & every parser (`formatQuery`, `parseSQL`, …)  |
| `@bootstrapdata/design-system/theme.css`         | Design tokens + `@theme` mapping                                                                    |
| `@bootstrapdata/design-system/flow.css`          | `@xyflow/react` base stylesheet (required by `Flow`)                                                |
| `@bootstrapdata/design-system/query-builder.css` | `react-querybuilder` themed stylesheet (required by `QueryBuilder`)                                 |
| `@bootstrapdata/design-system/assets/*`          | Logos, favicons, `site.webmanifest`                                                                 |

Prefer the granular subpaths for the best tree-shaking and Module Federation sharing.

## Theming

Tokens are defined in `theme.css` using OKLCH and mapped to Tailwind utilities via `@theme inline`. They cover:

- **Semantic colors** — `background`, `foreground`, `card`, `popover`, `primary`, `secondary`, `muted`, `accent`, `success`, `warning`, `info`, `destructive`, `border`, `input`, `ring`, `sidebar-*`, `chart-*`.
- **Brand scale** — `--color-brand-50` … `--color-brand-950` (hue 277), available as `bg-brand-500`, `text-brand-700`, etc.
- **Radii** — `--radius` with `sm`/`md`/`lg`/`xl`/`2xl` derivations.
- **Fonts** — `--font-sans` (Inter), `--font-mono` (JetBrains Mono).

Dark mode is class-based (`.dark`). Override any token by redefining the CSS variable in your app after importing `theme.css`.

Browse the live tokens in Storybook under **Foundations → Overview**.

## Components

### UI primitives

The complete shadcn/ui set (Button, Card, Dialog, DropdownMenu, Select, Table, Tooltip, …). `Tooltip` self-wraps its provider, so primitives work standalone.

### MultiSelect

A multi-value picker built on the Popover + Command + Badge primitives. Selected values render as removable badges that collapse into a "+N" summary past `maxCount`; the dropdown offers a search box (toggle with `hideSearch`) and per-option icons. Controlled via `value` / `onValueChange`, or uncontrolled via `defaultValue`.

```tsx
import { MultiSelect, type MultiSelectOption } from "@bootstrapdata/design-system/ui";

const options: MultiSelectOption[] = [
  { value: "us", label: "United States" },
  { value: "ca", label: "Canada" },
  { value: "gb", label: "United Kingdom" },
];

const [value, setValue] = useState<string[]>(["us"]);

<MultiSelect
  options={options}
  value={value}
  onValueChange={setValue}
  placeholder="Select countries"
  maxCount={3}
/>;
```

It also backs the query builder's `in` / `not in` editor — see [Query Builder](#query-builder).

![MultiSelect — searching, selecting and removing badges](docs/media/multi-select.gif)

### Layout

Framework-agnostic shell. Routing is injected via a `linkComponent` prop (e.g. React Router's `NavLink`/`Link`); labels are pre-resolved `ReactNode`s; active state comes from `currentPath` — no router/redux/i18n coupling.

### DataTable

```tsx
import { DataTable, DataTableToolbar, useDataTable } from "@bootstrapdata/design-system/data-table";

const { table } = useDataTable({ data, columns, initialState: { pagination: { pageSize: 10 } } });

return (
  <DataTable table={table}>
    <DataTableToolbar table={table} searchColumnId="name" />
  </DataTable>
);
```

Columns are standard TanStack `ColumnDef`s; add `meta: { variant: "multiSelect", options }` to light up faceted filters automatically. Pass `pageCount` to `useDataTable` to enable server-side mode.

![DataTable — column sorting and search filtering](docs/media/data-table.gif)

### Typography

```tsx
import { Text, CopyableText } from "@bootstrapdata/design-system/typography";

<Text variant="title">Page title</Text>
<Text variant="body" tone="muted" truncate tooltip>Long, truncating text…</Text>
<CopyableText variant="code" value="npm i @bootstrapdata/design-system">npm i @bootstrapdata/design-system</CopyableText>
```

### Wizard

Full-page, step-by-step overlay built on `Dialog`. Controlled like a dialog (`open` / `onOpenChange`), with an inline progress rail, scrollable body, and sticky footer.

```tsx
import { Wizard, type WizardStep } from "@bootstrapdata/design-system/wizard";
import { Button } from "@bootstrapdata/design-system/ui";

const steps: WizardStep[] = [
  { id: "type", label: "Type" },
  { id: "details", label: "Details" },
];

const [open, setOpen] = useState(true);
const [step, setStep] = useState(0);

return (
  <Wizard
    open={open}
    onOpenChange={setOpen}
    title="New connection"
    description="Set up a source to start ingesting events."
    steps={steps}
    currentStep={step}
    footer={
      <>
        <Button variant="outline" onClick={() => setStep((s) => Math.max(0, s - 1))}>
          Back
        </Button>
        <Button onClick={() => setStep((s) => s + 1)}>Continue</Button>
      </>
    }
  >
    {step === 0 ? <TypeStep /> : <DetailsStep />}
  </Wizard>
);
```

Keep `open` fixed to `true` and intercept `onOpenChange` to guard unsaved changes, or pass a `trigger` for an uncontrolled flow.

![Wizard — stepping forward and back through a flow](docs/media/wizard.gif)

### Code Editor

Monaco-based editor with a themed toolbar. The **Format** action uses `sql-formatter` for SQL and Monaco's document formatter for other languages; **Copy** writes the buffer to the clipboard with inline feedback. Toggle the whole toolbar with `toolbar={false}`, or the individual `showFormatAction` / `showCopyAction`. Monaco loads lazily, so it stays out of the main bundle.

```tsx
import { CodeEditor } from "@bootstrapdata/design-system/code-editor";

<CodeEditor label="query.sql" language="sql" value={query} onChange={setQuery} height={320} />;
```

![Code Editor — formatting a SQL buffer from the toolbar](docs/media/code-editor.gif)

### Flow

Design-system styled wrapper around `@xyflow/react` (provider, themed background, controls, optional minimap). Import the themed stylesheet once — it pulls in the xyflow base styles (into the `base` cascade layer) and re-skins them with the design-system tokens, so light/dark follow your theme automatically:

```tsx
import { Flow } from "@bootstrapdata/design-system/flow";
import "@bootstrapdata/design-system/flow.css";

<Flow nodes={nodes} edges={edges} showMiniMap />;
```

All xyflow hooks/types (`useNodesState`, `useEdgesState`, `Node`, `Edge`, …) are re-exported from the same subpath. If you import the CSS from your Tailwind entry instead, keep the layer ordering so Tailwind utilities can still override xyflow:

```css
@import "@bootstrapdata/design-system/flow.css" layer(base);
@import "tailwindcss";
```

![Flow — dragging a node around the pipeline canvas](docs/media/flow.gif)

### Drag and drop

`SortableList` is a batteries-included vertical sortable built on `@dnd-kit` (sensors, keyboard a11y and reordering handled for you). The full `@dnd-kit/core`, `@dnd-kit/sortable` and `@dnd-kit/modifiers` APIs are re-exported for advanced flows.

```tsx
import { SortableList } from "@bootstrapdata/design-system/dnd";

<SortableList
  items={items}
  getId={(i) => i.id}
  onReorder={setItems}
  renderItem={(item, handle) => (
    <div {...handle.attributes} {...handle.listeners}>
      {item.name}
    </div>
  )}
/>;
```

![Drag and drop — reordering a sortable list](docs/media/dnd.gif)

### Query Builder

Design-system styled wrapper around [`react-querybuilder`](https://react-querybuilder.js.org). Every control is a native shadcn/ui primitive (`Select`, `Input`, `Checkbox`, `Switch`, `Button`, …) wired via `controlElements`, so it matches the rest of the design system. Drag-and-drop rule reordering is wired up out of the box via the existing `@dnd-kit/core` dependency (toggle with `enableDragAndDrop={false}`). Import the themed stylesheet once — it maps react-querybuilder's container/branch variables onto the design tokens, so light/dark follow your theme automatically:

```tsx
import {
  QueryBuilder,
  formatQuery,
  type RuleGroupType,
} from "@bootstrapdata/design-system/query-builder";
import "@bootstrapdata/design-system/query-builder.css";

const fields = [
  { name: "event_name", label: "Event name" },
  { name: "revenue", label: "Revenue", inputType: "number" },
];

const [query, setQuery] = useState<RuleGroupType>({ combinator: "and", rules: [] });

<QueryBuilder fields={fields} query={query} onQueryChange={setQuery} />;

// Turn the query into SQL (or JSON, MongoDB, etc.) with the re-exported helpers:
const where = formatQuery(query, "sql");
```

![Query Builder — adding a rule and choosing a field](docs/media/query-builder.gif)

Use `combinatorPosition` to control where the AND/OR selectors render: `"header"` (default, one selector per group header), `"between"` (an inline selector between each rule), or `"left"` (inline combinators positioned to the left of their following rule/group):

```tsx
<QueryBuilder fields={fields} query={query} onQueryChange={setQuery} combinatorPosition="left" />
```

For `in` / `not in` filters, give the field `valueEditorType: "multiselect"` and a `values` list — it renders the shared `MultiSelect` primitive (search, removable badges, `maxCount` overflow, keyboard a11y), also available standalone from `@bootstrapdata/design-system/ui`:

```tsx
const fields = [
  {
    name: "country",
    label: "Country",
    valueEditorType: "multiselect",
    values: [
      { name: "US", label: "United States" },
      { name: "CA", label: "Canada" },
      { name: "GB", label: "United Kingdom" },
    ],
  },
];
```

Every `react-querybuilder` export is re-exported from the same subpath — the full main barrel (`formatQuery`, `transformQuery`, `defaultOperators`, all types, …) **plus every parser**, each of which lives in its own upstream subpath and is forwarded for you:

```tsx
import {
  parseSQL,
  parseCEL,
  parseGremlin,
  parseJsonLogic,
  parseMongoDB,
  parseCypher,
  parseJSONata,
  parseSPARQL,
  parseSpEL,
} from "@bootstrapdata/design-system/query-builder";
```

The parsers stay external runtime imports, so the four with heavier upstream peer dependencies are only pulled in if you actually use them. Install the matching peer dependency in your app first:

| Parser         | Required peer dependency     |
| -------------- | ---------------------------- |
| `parseCypher`  | `chevrotain`                 |
| `parseJSONata` | `jsonata`                    |
| `parseSPARQL`  | `@traqula/parser-sparql-1-2` |
| `parseSpEL`    | `spel2js`                    |

`parseSQL`, `parseCEL`, `parseGremlin`, `parseJsonLogic` and `parseMongoDB` need no extra dependencies.

If you import CSS from your Tailwind entry instead, keep the layer ordering so Tailwind utilities can still override the base styles:

```css
@import "@bootstrapdata/design-system/query-builder.css" layer(base);
@import "tailwindcss";
```

## Brand assets

```html
<link rel="icon" href="/assets/favicon.svg" type="image/svg+xml" />
<link rel="icon" href="/assets/favicon.ico" sizes="any" />
<link rel="apple-touch-icon" href="/assets/apple-touch-icon.png" />
<link rel="manifest" href="/assets/site.webmanifest" />
```

React logo components are also exported:

```tsx
import { BootstrapDataLogo, BootstrapDataMark } from "@bootstrapdata/design-system";
```

Favicons are regenerated from `src/assets/favicon.svg` on every build.

## Module Federation

These packages **must be shared singletons** across host and remotes to avoid duplicate React/context instances:

- `react`, `react-dom`
- `lucide-react`
- `@tanstack/react-table`

Share `@bootstrapdata/design-system` itself as a singleton and bump its version in lockstep across all apps. Keep your own `@import "tailwindcss"` in each app (the package ships only tokens, not the Tailwind runtime).

## Development

```bash
npm install            # installs deps; husky sets up git hooks
npm run storybook      # component workbench at http://localhost:6006
npm run build          # tsup -> dist (ESM + d.ts) + favicons
npm run typecheck      # tsc --noEmit
npm run lint           # eslint (incl. jsx-a11y)
npm run format         # prettier --write
```

A pre-commit hook (husky + lint-staged) runs ESLint and Prettier on staged files.

## Scripts

| Script                    | Description                                              |
| ------------------------- | -------------------------------------------------------- |
| `build`                   | Generate favicons, then bundle with tsup (ESM + `.d.ts`) |
| `dev`                     | tsup in watch mode                                       |
| `storybook`               | Run Storybook dev server                                 |
| `build-storybook`         | Build the static Storybook                               |
| `typecheck`               | `tsc --noEmit`                                           |
| `lint` / `lint:fix`       | ESLint (with auto-fix)                                   |
| `format` / `format:check` | Prettier write / check                                   |
| `assets:favicons`         | Regenerate favicons from `favicon.svg`                   |
| `changeset`               | Record a change for release                              |
| `changeset:version`       | Apply changesets, bump version, update CHANGELOG         |
| `release`                 | Build and publish to the registry                        |

## Project structure

```
src/
  assets/        # logo + favicon source, logo React components
  components/
    ui/          # shadcn/ui primitives (managed via the shadcn CLI)
    layout/      # AppShell, AppSidebar, SiteHeader, Breadcrumbs, …
    data-table/  # TanStack DataTable + parts
    typography/  # Text, CopyableText
  styles/
    theme.css    # design tokens (published)
    globals.css  # dev/build entry
  index.ts       # package barrel
stories/         # Storybook stories
.storybook/      # Storybook config
```

## Adding a component

```bash
npx shadcn@latest add <component>
# then export it from src/components/ui/index.ts and the package barrel (src/index.ts)
```

For new design-system components, add them under `src/components/<area>/`, export from the relevant barrel, and add a story under `stories/`.

## Publishing

Published to **GitHub Packages** (registry `https://npm.pkg.github.com`). The npm scope `@bootstrapdata` matches the GitHub org `bootstrapdata`, as GitHub Packages requires.

Releases use [Changesets](https://github.com/changesets/changesets) and follow [Semantic Versioning](https://semver.org): **patch** for fixes, **minor** for backwards-compatible features, **major** for breaking changes.

### Automated (recommended)

1. Include a changeset in your PR:
   ```bash
   npm run changeset
   ```
2. On merge to `main`, the **Release** workflow opens a "Version Packages" PR (bumps the version, updates `CHANGELOG.md`).
3. Merging that PR builds and publishes to GitHub Packages using the built-in `GITHUB_TOKEN`.

### Manual (local)

```bash
export NODE_AUTH_TOKEN=<GitHub PAT with write:packages>
npm run changeset:version   # bump version + CHANGELOG
npm run release             # build + changeset publish
```

Because consumers may pin exact versions for Module Federation, coordinate bumps across dependent apps.

## License

UNLICENSED — © Bootstrap Data. Internal use only.
